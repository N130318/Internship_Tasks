<?php
	include 'db_connection.php';
	session_start();
	$useremail=$_SESSION['user'];
	$sql="select * from tbl_login where email='$useremail'";
	$result=mysqli_query($dbConnection,$sql);
	//$result=$dbConnection->query($sql);
	$row=mysqli_fetch_assoc($result);
	echo "<img src='rgukt.jpg' width='100%' height='100px' style='margin-top:0px;' align='center'/>
	<div style='padding-left:1230px;'><a href='signout.php'>Logout</a></div>
	<div style='margin-top:10px;'><center><h1>Welcome, $row[first_name] $row[last_name]</h1><br>
	<h3>Your Registered Details:</h3><br>
	<b>User Id:</b> $row[user_id]<br><br>
	<b>First Name:</b> $row[first_name]<br><br>
	<b>Last Name:</b> $row[last_name]<br><br>
	<b>Gender:</b> $row[gender]<br><br>
	<b>E-Mail:</b> $row[email]<br><br>
	<b>Address:</b> $row[address]<br><br>
	<b>Mobile Number:</b> $row[mobile_no]<br><br>
	</center><br><br></div>";	
?>	
