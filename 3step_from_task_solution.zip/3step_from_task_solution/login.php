<?php
session_start();
include 'db_connection.php';
if(isset($_POST['login']))
{

	$email = $_POST['email'];
	$pwd = $_POST['paswd'];


	$sql="SELECT *FROM tbl_login WHERE email='$email' AND password='$pwd'";

	$result=$dbConnection->query($sql);

	if(!$row=$result->fetch_assoc())
	{
		echo "Your Username or password is incorrect!";
	}
	else
	{
		//echo "You are logged in!";
		$_SESSION['user']=$email;
		?><script>window.location.assign('welcome.php');</script><?php
		
	}
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Login Page</title>
	</head>
	<body align="center">
		<h1>Login Page</h1>
		<form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>">
			<input type="text" name="email" placeholder="Enter Email"> <br><br><br>
			<input type="password" name="paswd" placeholder="Enter Password"><br><br><br>
			<button type="submit" name="login">Login</button>
			<button type="reset">Clear</button><br><br>
			<div>New User? <a href="index.php">Click Here to Register</a><br /></div>
		</form>		
	</body>
</html>
