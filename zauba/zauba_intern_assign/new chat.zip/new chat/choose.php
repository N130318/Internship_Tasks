<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Chat System Home</title>
<body bgcolor="pink">
    <font size="5pt" face="Times New Roman" color="black">
</head><center>
Hello you are Higly Welcome, this is a simple chatting system created in other to make information transmission very easily.
<br />
<p><h1>Choose Below to Continue</h1><a><strong>
<a href="cht">Chat Page</p></a>
<br /><br>
</br></br><a href="logout.php">Log Out</a>
<body>
</body>
<br /><br><br /><br><br /><br><br />
<p><Strong><center> Programmed and Design by M.Gopi</center></Strong></p>
</html>
