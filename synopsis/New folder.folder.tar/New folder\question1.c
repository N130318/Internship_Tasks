#include<stdio.h>
int main()
{
	int arr[100],i,j;
	printf("enter the size of the array");
	scanf("%d",&arr[10]);
	for(i=0;i<100;i++)
	{
	printf("enter values i:%d\n",i);
	}
	for(j=0;j<100;j++)
	{
	printf("Enter the values j:%d\n",j);
	}
	for(i=0;i<100;i++)
	{
		for(j=0;j<100;j++)
		{
			printf("Enter the adjacent values of array%d %d",i j);
		}
	}	
}
