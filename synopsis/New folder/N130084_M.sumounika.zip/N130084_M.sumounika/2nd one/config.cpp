application.service.name=${SEVICE_NAME}
application.service.protocol=${SEVICE_protocol}
application.service.port=${SEVICE_port}
application.service.address=${SEVICE_protocol}

