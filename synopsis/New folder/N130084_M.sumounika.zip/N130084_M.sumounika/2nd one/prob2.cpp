#include<stdio.h>
#include<fcntl.h>
main()
{
int fd1,fd2,n;
 char buf[1000];
 fd1=open("config.cpp",O_RDONLY);
 fd2=open("application.cpp",O_RDONLY);
 n=read(fd1,buf,1000);
 char buf2[1000];
 int m=read(fd2,buf2,1000);
 int i,j=0,k;
 for(i=0;i<n;i++)
 {
		if(buf[i]=="n"&&buf[i+1]=="a"&&buf[i+2]="m"&&buf[i+3]=="e"){
		
		for(j=0;j<m;j++)
		{
			if(buf2[j]=='n'&&buf2[j+1]=='a'&&buf2[j+2]='m'&&buf2[j+3]=='e')
			{
			for(k=j+1;buf2[k]!='\n';k++)
			printf("%c",buf2[k]);
			break;}
		}
	   }
	  else if(buf[i]=='p'&&buf[i+1]=='r'&&buf[i+2]='o'&&buf[i+3]=='t'){
		
		for(j=0;j<m;j++)
		{
			if(buf2[j]=='p'&&buf2[j+1]=='r'&&buf2[j+2]='o'&&buf2[j+3]=='t'){
			
			for(k=j+1;buf2[k]!='\n';k++)
			printf("%c",buf2[k]);
			break;
		}
		}
	   }
			
		 else if(buf[i]=='p'&&buf[i+1]=='o'&&buf[i+2]='r'&&buf[i+3]=='t'){
		
		for(j=0;j<m;j++)
		{
			if(buf2[p]=='p'&&buf2[j+1]=='o'&&buf2[j+2]='r'&&buf2[j+3]=='t'){
			
			for(k=j+1;buf2[k]!='\n';k++)
			printf("%c",buf2[k]);
			break;
		}
		}
	   }
	   	
		 else if(buf[i]=='a'&&buf[i+1]=='d'&&buf[i+2]='d'&&buf[i+3]=='r'){
		
		for(j=0;j<m;j++)
		{
			if(buf2[j]=='s'&&buf2[j+1]=='t'&&buf2[j+2]='a'&&buf2[j+3]=='u'){
			
			for(k=0;buf2[k]!='\0';k++)
			{
				int p=k;
				
			printf("%c",buf2[k]);
		}
			break;
		}
		}
	   }	
		printf("%c",buf[i]);	
			
	}
		
		
		
	
 
 
 
  
 close(fd1);
 close(fd2);
}
