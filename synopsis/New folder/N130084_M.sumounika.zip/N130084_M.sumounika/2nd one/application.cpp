SERVICE_name=facebook.in
SERVICE_protocol=https
SERVICE_port=443
SERVICE_status=available
