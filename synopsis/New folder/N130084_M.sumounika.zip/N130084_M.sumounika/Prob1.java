import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Prob1{

    public static void main(String[] args) {
   int n,t,i,j,min,sum;

	Scanner sc=new Scanner(System.in);
	t=sc.nextInt();
	for(i=0;i<t;i++)
        {
         n=sc.nextInt();
         int arr[]=new int[n];
                for(j=0;j<n;j++)
                   arr[j]=sc.nextInt();

          min=arr[0];sum=0;
                for(j=1;j<n;j++)
                 {
			if(min>arr[j])
				min=arr[j];
 		}

	for(j=0;j<n-1;j++)
	sum=sum+min;
	System.out.println(sum);
	}

}
}

