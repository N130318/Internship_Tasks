#include<stdio.h>

int main()
{
	int t,i,n,j,k;
	scanf("%d",&t);
	int *a[t],size[t],sum[t],cost;
	for(i=0;i<t;i++)
	{
		scanf("%d",&size[i]);
		int b[size[i]];
		for(j=0;j<size[i];j++)
		{
			scanf("%d",&b[j]);
		}
		a[i]=b;
		//process
		k=0;
		sum[i]=0;
		for(j=0;j<size[i]-1;j++)
		{
			if(a[i][j]>a[i][j+1])
			{
				a[i][k++]=a[i][j+1];
				cost=a[i][j+1];
			}
			else if(a[i][j]<a[i][j+1])
			{
				a[i][k++]=a[i][j];
				cost=a[i][j];
			}
			sum[i]=sum[i]+cost;
		}
		a[i][k]='\0';
	}
	//output printing.
	printf("Output:\n");
	for(i=0;i<t;i++)
		printf("\%d\n",sum[i]);
}
