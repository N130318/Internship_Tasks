#include<stdio.h>
int main()
{
	int n,m,i,j,k;
	scanf("%d",&n);
	int arr[n][100];
	for(i=0;i<n;i++)
	{
		scanf("%d",&m);
		for(j=0;j<m;j++)
		 scanf("%d",&arr[i][j]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
		   if(arr[i][0]>arr[i][j])
		     m=arr[i][i];
		    else
		     m=arr[i][j];
	    } 
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		printf("%d",arr[i][j]);
    }
	return 0;
}
    
