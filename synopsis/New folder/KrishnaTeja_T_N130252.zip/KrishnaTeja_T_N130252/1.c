#include<stdio.h>
int main()
{
	int n,arr[n],i,t,j,c;
	scanf("%d",&t);//test cases
	scanf("%d",&n);//noof elements
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[n]);//arrray elements
		//printf("%d",arr[n]);
		if(arr[i+1]<arr[i])
		{
			arr[n]=arr[n-i];
			c=arr[n];
			printf("%d",c);
		}
		if(arr[i]<arr[i+1])
		{
			arr[n]=arr[n-i];
			c=arr[n-i];
			printf("%d",c);
		}
	}
}
