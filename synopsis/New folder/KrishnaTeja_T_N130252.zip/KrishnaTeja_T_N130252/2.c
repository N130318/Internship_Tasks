#include<stdio.h>
#include<fcntl.h>
int main()
{
	int fd;  /* write (1, buf, n) */
	char buf[100];
	fd =open ("application.config", O_RDONLY);
	n=read (fd, buf, 100);
	for (i=0; buf[i]! ='\0'; i++)
	{
		if(buf[i]=='$')
		
	} 
}

