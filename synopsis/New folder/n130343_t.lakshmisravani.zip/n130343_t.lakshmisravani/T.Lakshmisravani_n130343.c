#include<stdio.h>
int main()
{
int n,i,x,y,cost=0;
printf("enter the size of the array");
scanf("%d",&n);
int array[n];
printf("enter the elements of the array");
for(i=0;i<n;i++)
{
scanf("%d",&array[i]);
}
printf("the array elements are");
/*for(i=0;i<n;i++)
{
printf("%d",array[i]);
}*/
int j=n;
for(i=0;i<j-1;i++)
{
printf("select any two positions");
scanf("%d",&x);
scanf("%d",&y);
if(array[x]<array[y])
{
cost=cost+array[x];
for(i=y;i<n;i++)
array[i]=array[i+1];
printf("%d",array[i]);
}
n=n-1;
}
else
{
cost=cost+array[y];
for(i=x;i<=n;i++)
{
array[i]=array[i+1];
printf("%d",array[i]);
}
n=n-1;
}
}
printf("the elements of the array are");
printf("%d",cost);
return 0;
}


