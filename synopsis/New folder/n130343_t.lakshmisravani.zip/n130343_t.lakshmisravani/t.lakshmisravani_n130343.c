#include<stdio.h>
int main()
{
	FILE *fp;
	fp=fopen("f.conf","r");
        while((fscanf(f,"%s %d",name,&id))!=EOF)
        fprintf(fp2,"%s %d\n",name,id);
	return 0;
}
